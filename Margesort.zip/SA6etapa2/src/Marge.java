import java.util.Arrays;

public class Marge {

    public static void main(String[] args) {
        int[]v = {1,7,10,9,2,3,20,18,33,90,44,34,30,21,27,5,8,99,54,68};
        int[]x = new int[v.length];
        
        mergeSort(v, x, 0, v.length-1);
        System.out.println(Arrays.toString(v));
        }

    private static void mergeSort(int[]v, int[]x, int ini, int fim) {
        if(ini < fim) {
            int meio = (ini + fim) /2;
            mergeSort(v, x, ini, meio);
            mergeSort(v, x, meio+1, fim);
            intercalar(v, x, ini, meio, fim);
        }  
    }

    private static void intercalar(int[]v, int[]x, int ini, int meio, int fim) {
        for(int i = ini; i <= fim; i++)
            x[i] = v[i];
        
        int a = ini; 
        int b = meio+1; 
        
        for(int i = ini; i <= fim; i++) { 
            if(a > meio) v[i] = x[b++];
            else if(b > fim) v[i] = x[a++];
            else if(x[a] < x[b]) v[i] = x[a++];
            else v[i] = x[b++]; 
        }
    }
}