package ATVb;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int a, b, c, d;

		Diferenca s1 = new Diferenca();

		System.out.println("Digete o primeiro n�mero: ");
		a = sc.nextInt();
		System.out.println("Digete o segundo n�mero: ");
		b = sc.nextInt();
		System.out.println("Digete o terceiro n�mero: ");
		c = sc.nextInt();
		System.out.println("Digete o quarto n�mero: ");
		d = sc.nextInt();

		s1.diferenca(a, b, c, d);
		sc.close();
	}

}
