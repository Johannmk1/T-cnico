package ATVb;

public class Diferenca {

	int a;
	int b;
	int c;
	int d;
	int val;
	
	public void diferenca(int a,int b,int c,int d) {
		System.out.println(a * b - c * d);
	}
	
	
}
