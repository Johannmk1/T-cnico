package ATVa;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int a, b, c, d, e;
		
		Soma s1 = new Soma();
		
		System.out.println("Digete o primeiro n�mero: ");
		a = sc.nextInt();
		System.out.println("Digete o segundo n�mero: ");
		b = sc.nextInt();
		System.out.println("Digete o terceiro n�mero: ");
		c = sc.nextInt();
		System.out.println("Digete o quarto n�mero: ");
		d = sc.nextInt();
		System.out.println("Digete o quarto n�mero: ");
		e = sc.nextInt();
		
		System.out.println("Os n�meros somados s�o: "+ a+", "+ b+", "+ c+", "+ d+" e "+ e+ ".");
		System.out.println("O resultado da soma �: ");
		System.out.println("=======================");
		s1.Somar(a, b, c, d, e);
		System.out.println("=======================");
		
	sc.close();
	}

}
