package ATVa;

public class Soma {
	
	int a;
	int b;
	int c;
	int d;
	int e;
	
	
	void Somar(int a,int b,int c,int d,int e) {
		System.out.println("         "+(a + b + c + d + e));
	}
}
