package ATVc;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	
		int nr;
		int h;
		double s;
		
		Calculo c1 = new Calculo();
		
		System.out.print("Digite o n�mero da matricula: ");
		nr = sc.nextInt();
		
		System.out.print("Digite o n�meros de horas trabalhadas: ");
		h = sc.nextInt();

		System.out.print("Digite quanto voc� ganha por hora: ");
		s = sc.nextDouble();
		
		c1.calculo(nr, h, s);
		
		sc.close();
	}

}
