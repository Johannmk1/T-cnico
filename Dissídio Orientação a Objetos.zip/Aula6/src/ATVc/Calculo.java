package ATVc;

public class Calculo {

	String nr;
	int h;
	double s;
	
	
	void calculo(int nr,int h,double s) {
		System.out.println(nr+ " Receber�: "+ (s * h));
	}
}
