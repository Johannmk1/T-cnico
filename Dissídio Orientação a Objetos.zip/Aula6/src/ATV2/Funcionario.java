package ATV2;

public class Funcionario {

	String nome;
	float salario;
	int aumento;

	void Dissidio(float salario, int aumento) {
		System.out.println("R$"+ (((salario / 100) * aumento) + salario));
	}

}
