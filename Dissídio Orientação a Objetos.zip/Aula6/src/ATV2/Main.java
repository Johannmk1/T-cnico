package ATV2;

import java.util.Scanner;

public class Main {

	  public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        String nome;
	        float salario;
	        int aumento;

	        Funcionario f1 = new Funcionario();

	        System.out.println("Digite seu nome: ");
	        nome = sc.nextLine();
	        System.out.println("Digite seu sal�rio: ");
	        salario = sc.nextFloat();
	        System.out.println("Digite o diss�dio: ");
	        aumento = sc.nextInt();

	        System.out.println(nome+ " seu sal�rio ser�: " );
	        f1.Dissidio(salario, aumento);

	        sc.close();

	    }

	}