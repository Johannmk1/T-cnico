package ATV;

public class atividade {

	public static void BubbleSort(int v[]) {

        for (int i = v.length; i >= 1; i--) {
            for (int j = 1; j < i; j++) {
                if (v[j - 1] > v[j]) {
                    int aux = v[j];
                    v[j] = v[j - 1];
                    v[j - 1] = aux;
                }
            }
        }
    }

    public static void main(String[] args) {
        int[] v = { 1,7,10,9,2,3,20,18,33,90,44,34,30,21,27,5,8,99,54,68};
        BubbleSort(v);
        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i]);

        }
    }
}