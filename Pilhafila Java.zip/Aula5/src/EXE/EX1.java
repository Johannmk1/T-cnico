package EXE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class EX1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numbers = 12;

		ArrayList<String> jogador = new ArrayList<String>();
		for (int i = 1; i <= numbers; i++) {
			System.out.println("Digite o nome do " + (i) + "� jogador: ");
			jogador.add(sc.next());
		}
		Collections.sort(jogador);
		System.out.println("Escala��o dos jogadores:");
		System.out.println(jogador);

		sc.close();

	}

}
