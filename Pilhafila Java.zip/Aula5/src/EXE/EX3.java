package EXE;

import java.util.HashMap;
import java.util.Scanner;

public class EX3 {

	public static void main(String[] args) {
		HashMap<Integer, String> lanches = new HashMap<Integer, String>();
		Scanner sc = new Scanner(System.in);
		int r = 0, a = 1, b = 2, c = 3, d = 4, e = 5;

		lanches.put(1, "Pastel");
		lanches.put(2, "Coxinha");
		lanches.put(3, "Bolinho");
		lanches.put(4, "X-Salada");
		lanches.put(5, "Empada");

		System.out.println("Cardapio: " + lanches);

		System.out.println("Qual lanche voc� deseja comer?");
		r = sc.nextInt();

		if (r == a) {
			System.out.println("Voc� escolheu o lanche: " + lanches.get(1));
		}

		if (r == b) {
			System.out.println("Voc� escolheu o lanche: " + lanches.get(2));
		}
		if (r == c) {
			System.out.println("Voc� escolheu o lanche: " + lanches.get(3));
		}
		if (r == d) {
			System.out.println("Voc� escolheu o lanche: " + lanches.get(4));
		}
		if (r == e) {
			System.out.println("Voc� escolheu o lanche: " + lanches.get(5));
		}
		sc.close();
	}
}