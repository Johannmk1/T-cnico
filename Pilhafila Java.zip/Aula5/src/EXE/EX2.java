package EXE;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class EX2 {

	public static void main(String[] args) {
		Queue<String> fila = new LinkedList<String>();
		Scanner sc = new Scanner(System.in);

		int carros = 6;

		for (int i = 1; i <= carros; i++) {
			System.out.println("Digite o nome do " + (i) + "� carro: ");
			fila.add(sc.next());
		}
		System.out.println("Primeiro que ser� atendido � o: " +fila.poll());
		System.out.println("E o segundo � o: " + fila.peek());
		sc.close();
		}

}