package EXE;

import java.util.Scanner;
import java.util.Stack;

public class EX4 {

	public static void main(String[] args) {
		Stack<String> produto = new Stack<>();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite o nome do produto 1: ");
		produto.push(sc.nextLine());
		System.out.println("Digite o nome do produto 2: ");
		produto.push(sc.nextLine());
		System.out.println("Digite o nome do produto 3: ");
		produto.push(sc.nextLine());
		System.out.println("Digite o nome do produto 4: ");
		produto.push(sc.nextLine());
		System.out.println("Digite o nome do produto 5: ");
		produto.push(sc.nextLine());
		
		System.out.println("O primeiro produto �: " + produto.pop());
		System.out.println("O segundo �: " + produto.pop());
	
	
		
	
		if(produto.empty()) {
			System.out.println("O caminh�o est� vazio!");
			}else {
				System.out.println("O terceiro �: " +produto.peek());
		
			}
		
		
	sc.close();	
	}

}
