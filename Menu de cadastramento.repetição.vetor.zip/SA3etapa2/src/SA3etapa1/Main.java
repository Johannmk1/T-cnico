package SA3etapa1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		// variaveis
		int tamanhovetor = 0, r = 0;
		int a = 1, b = 2, c = 3, conta = 1;

		// tamanho do vetor
		System.out.print("Quantos novos usu�rios ser�o cadastrados? ");
		tamanhovetor = sc.nextInt();
		System.out.println("");

		// declarando os vetores
		String[] nome = new String[tamanhovetor];
		int[] idade = new int[tamanhovetor];

		// novo usu�rio

		while (conta != 2) {

			System.out
					.println("1. Cadastrar novos usu�rios \n 2. Lista dos usu�rios \n 3.Buscar usu�rio j� cadastrado ");
			r = sc.nextInt();

			if (r == a) {
				System.out.println("=============================================================== ");
				System.out.println("================Cadastramento de novos usu�rios================ ");
				System.out.println("=============================================================== ");
				for (int i = 0; i != tamanhovetor; i++) {
					System.out.println("Digite o nome do novo usu�rio: ");
					nome[i] = sc.next();
					System.out.println("Digite a idade do novo usu�rio: ");
					idade[i] = sc.nextInt();
				}
			}

			// Listar todos os usu�rios
			if (r == b) {

				System.out.println("=============================");
				System.out.println("======Lista de usu�rios======");
				System.out.println("=============================");
				for (int i = 0; i < tamanhovetor; i++) {

					System.out.println("  Nome: " + nome[i] + " Idade: " + idade[i] + "  ");
					System.out.println("=============================");
				}
			}
			System.out.println("");

			// Sair
			if (r == c) {
				System.out.println("Programa encerrado");
				conta++;
			}
		}
		sc.close();
	}
}
