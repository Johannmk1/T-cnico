import java.util.Scanner;
import java.util.Stack;

public class Main {

	public static void main(String[] args) {

		Stack<String> pilha = new Stack<>();
		Scanner sc = new Scanner(System.in);

		int a = 1, b = 2, c = 3, d = 4, e = 5, conta = 1, r = 0;
		int produtos = 0, tamanhopilha = 0;

		while (conta != 2) {

			System.out.println("1. Empilhar \n 2. Desempilhar \n 3.Limpar \n 4.Listar \n 5.Vazia ");
			r = sc.nextInt();

			// Empilhar
			if (r == a) {
				System.out.println(" ");
				System.out.println("Adicione no maximo 20 produtos");
				System.out.println("Sua pilha tem "+ tamanhopilha+ " produtos");
				System.out.println(" ");
				System.out.println("Digite um produto");
				String nome = sc.next();
				pilha.add(nome);
				produtos++;
				tamanhopilha++;
				System.out.println(" ");
			}

			// Desempilhar
			if (r == b) {
				System.out.println(" ");
				System.out.println("O produto de cima �: " + pilha.pop());
				System.out.println("A pilha ficou: " + pilha);
				System.out.println(" ");
				produtos--;
				tamanhopilha--;
			}

			// Limpar
			if (r == c) {
				System.out.println(" ");
				for (int i = 0; i < produtos; i++) {
					System.out.println("Removendo... " + pilha.pop());
				}
				System.out.println(" ");
			}

			// Listar
			if (r == d) {
				System.out.println(" ");
				System.out.println(pilha);
				System.out.println(" ");
			}

			// Vazia
			if (r == e) {
				System.out.println(" ");
				if (pilha.empty()) {
					System.out.println("A pilha est� vazia!");
				} else {
					System.out.println("Existem elementos na pilha!");
				}
				System.out.println(" ");
			}
			
			//Se for maior que 20
			if (produtos > 20) {
				System.out.println("=================================");
				System.out.println("|Limite maximo da pilha atingido|");
				System.out.println("|    :( Programa encerrado      |");
				System.out.println("=================================");
				conta++;

			}
		}

		sc.close();
	}

}
