import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class ATV {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Queue<String> fila = new LinkedList<String>();

		int a = 1, b = 2, c = 3, d = 4, e = 5, conta = 1, r = 0, usuario = 0;

		while (conta != 2) {

			System.out.println("1. Adicionar \n 2. Remover \n 3.Limpar \n 4.Listar \n 5.Vazia");
			r = sc.nextInt();

			//Adicionar
			if (r == a) {
				System.out.println("Digite o nome do novo usu�rio");
				String nome = sc.next();
				fila.add(nome);
				usuario++;
			}
			
			//Remover
			if (r == b) {
				System.out.println("Usuario exclu�do: " + fila.poll());
				usuario--;
			}
			
			//Limpar
			if (r == c) {
				for (int i = 0; i < usuario; i++) {
					System.out.println("Removendo... " + fila.poll());
					usuario = 0;
				}
			}
			
			//Listar
			if (r == d) {
				System.out.println(fila);
			}
			
			//Vazia
			if (r == e) {
				if (usuario <= 0) {
					System.out.println("A fila est� vazia!");
				} else {
					System.out.println("Existem elementos na fila!");
				}
			}
			
			//Limite
			if (usuario > 20) {
				System.out.println("================================");
				System.out.println("|Limite maximo da fila atingido|");
				System.out.println("|    :( Programa encerrado     |");
				System.out.println("================================");
				conta++;

			}

		}
		sc.close();
	}

}
