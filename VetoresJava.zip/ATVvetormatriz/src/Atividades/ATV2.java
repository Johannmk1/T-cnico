package Atividades;

import java.util.Scanner;

public class ATV2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        int n = 10;
        int valor[] = new int[n]; 
        int contador = 1;
        String resultado ="";

        for (int i = 0; i < n; i++) {
            System.out.print("DIGITE O " +contador+ "� N�MERO: ");
            valor[i] = sc.nextInt();

            if (valor[i] % 2 != 1) {
                resultado = resultado+ valor[i];

                if (contador <10) {
                    resultado = resultado + ", ";
                }

                }

            contador++;

            }

        System.out.println("DOS N�MEROS DIGITADOS, OS SEGUINTES S�O PARES: " +resultado+".");

        sc.close();

}

}