package Atividades;

import java.util.Scanner;

public class ATV1 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int bike;
		double[] vetor;
		double preco = 0;
		
		System.out.print("Digite quantas bicicletas tem em estoque: ");
		bike = sc.nextInt();
		
		vetor = new double[bike];
		
		for (int i = 0; i < bike; i++) {
			System.out.print("Digite o pre�o da bicicleta " + (i + 1) + ": R$ ");
			vetor[i] = sc.nextDouble();
			preco = preco + vetor[i] -1;
		}
		preco = preco + bike;
		for (int i = 0; i < bike; i++) {
			System.out.println("O valor da bicicleta " + (i + 1) + " � R$ " + vetor[i] + ".");
		}
		System.out.println("O valor total dos produtos � R$" + preco);
		sc.close();

	}

}
