package Atividades;

import java.util.Scanner;

public class ATV3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        int[][] matriz = new int[6][6];


        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print("Insira o o valor para posi��o : [" + (i + 1) + "]  [" + (j + 1) + "]");
                matriz[i][j] = Integer.parseInt(sc.nextLine());

            }

        }

        System.out.println("A matriz ficou: ");
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                System.out.print(matriz[i][j] + " - ");



            }
            System.out.println();
        }

        System.out.println(" Os numeros que est�o entre [10..50] s�o: ");
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                if (matriz[i][j] > 9 && matriz[i][j] < 51) {
                    System.out.print(matriz[i][j] + " - ");


                }

            }

            sc.close();
        }
    }
}